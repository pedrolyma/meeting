import { Meeting } from "./meeting";

export class MeetingPage {
  content?: Meeting[];
  pageInicial: number =0;
  pageSize: number=0;
  totalRegistros: number = 0;

}
