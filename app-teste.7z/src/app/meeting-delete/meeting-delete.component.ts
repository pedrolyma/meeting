import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meeting-delete',
  templateUrl: './meeting-delete.component.html',
  styleUrls: ['./meeting-delete.component.css']
})
export class MeetingDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
